function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}

function handleSubmit() {
  alert("Thank you for contacting me!");
  return false;
}
